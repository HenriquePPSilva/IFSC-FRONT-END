// Chamada de função após página completamente carregada
window.onload= function() {
    alert("Meu primeiro alert!");
}